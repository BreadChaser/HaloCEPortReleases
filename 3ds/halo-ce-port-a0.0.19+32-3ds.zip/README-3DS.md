# 3DS CE Map Probe

This is the 3DS-native target for the Halo CE runtime work. It does not ship Halo assets, maps, sounds, names, logos, or executable code.

The current build links the shared C `.map` runtime probe and opens legally owned CE/MCC map files from the 3DS SD filesystem. The old raycast/`.r3m` prototype code has been removed.

The target compiles shared engine source directly through `../../engine/sources.mk`
instead of maintaining 3DS-only bridge files. New portable engine files added
for Linux under `engine/cache`, `engine/game`, `engine/objects`, `engine/physics`,
`engine/tags`, or `engine/net` are included in the 3DS build automatically.
3DS now builds the same relay socket transport used by Linux/Windows for
cross-play, plus a separate libctru UDS backend selected by the `3ds-local`
host name for no-internet local wireless.

## Build

Requires devkitPro with libctru/citro2d/citro3d.

```bash
cd targets/3ds-ringworld-prototype
make
```

Output:

```text
ringworld3ds.3dsx
```

Send to a 3DS running the Homebrew Launcher:

```bash
make send
```

The repo-level release scripts build the same target through `make build-3ds`
and package the versioned `.3dsx` from `bin/3ds/` into GitHub/playtest
releases unless `--skip-3ds` is passed.

## Map Loading

Put owned `.map` files on the 3DS SD card or emulator SD card under:

```text
/halo/maps/
```

The app uses the shared runtime path list. On 3DS it searches these roots:

```text
sdmc:/halo/maps/
romfs:/maps/
```

Within those roots it checks the same built-in candidate map names used by the desktop/runtime harness where possible: `bloodgulch.map`, `beavercreek.map`, `sidewinder.map`, `deathisland.map`, and `start.map`.

The bottom-screen map list uses short fixed labels such as `SD bloodgulch.map` and `ROM bloodgulch.map`; the full SD/ROMFS path is still used internally.

The app is a simple menu-driven loader. It scans known map names, lets you select an available map, then synchronously loads through the same `halo_map_load()` path used by the Linux runtime. After load, the top screen enters a low-settings Citro3D world view built from the shared BSP render mesh and drives the camera through the shared fixed-tick `HaloGameWorld` path. That means player movement, combat state, weapon inventory ticks, projectile ticking, and parsed vehicle placement state now come from the same native runtime layer used by the desktop target.

The 3DS renderer now defaults to a hardware-safe FAST profile: it caps the world
draw at 1,800 BSP faces, decodes only the low-resolution material textures used
by that visible face budget, and batches world triangles by texture slot to keep
draw calls low. Press `L`/`R` from the map menu before loading to cycle FAST,
MID, and FULL geometry budgets. Player collision still uses the full parsed BSP
surface set through a small 3DS-side collision grid, so the render budget does
not cut away the ground or walls around the spawn point.

Press `Y` from the map menu before loading to disable or enable the texture path.
That path is capped at 16 decoded 32x32 material textures for now, so it is not
desktop parity, but it keeps textured gameplay usable on 3DS instead of falling
back to the color-only debug view.

## Local Wireless

Press `Select` from the map menu to open the 3DS local-wireless menu. Hosts can
advertise the selected map as a local UDS lobby without internet. Clients can
browse nearby lobbies, join, toggle ready, and enter the match when the host
starts it. Both systems must already have the same owned `.map` file installed
under the normal 3DS map search paths.

The in-game local-wireless path reuses the shared desktop lobby/session protocol
over UDS frames. To stay inside the 3DS hardware budget, the 3DS match uses the
FAST render profile by default, no map downloads, static vehicle placement, and
the existing lightweight combat/player synchronization.

When a map is loaded, the target tries to read native weapon tag data from that `.map` for the built-in weapon set plus weapon paths referenced by netgame equipment and placed weapon objects. If that fails, it keeps the same built-in fallback weapon tuning used by the shared runtime tests.

The 3DS build writes a small debug log to `sdmc:/halo/ringworld3ds_debug.log`. In Azahar's Flatpak sandbox this usually appears on the host at `~/.var/app/org.azahar_emu.Azahar/data/azahar-emu/sdmc/halo/ringworld3ds_debug.log`. It records map-load phase timings, selected geometry profile, face/draw counts, texture count, runtime tick, and rolling frame timing.

For emulator debugging, create `sdmc:/halo/ringworld3ds_autoload.txt` to boot straight into a map without controller input:

```text
map=bloodgulch.map
profile=FAST
textures=off
perf=on
perf_frames=600
perf_quit=on
```

With `perf=on`, the runtime records a fixed loaded-map frame sample to
`ringworld3ds_debug.log` with average/min/max frame time, slow-frame counts,
drawn/source faces, draw calls, texture count, and runtime ticks. `perf_quit=on`
exits after the sample so repeated hardware runs are comparable.

For relay cross-play testing against PC/Linux, the same autoload file can start
the map as a relay host or client:

```text
map=bloodgulch.map
profile=FAST
textures=off
net=relay-host
relay_host=192.168.1.20
relay_port=17776
relay_room=XPLAY3D
```

Use `net=relay-client` on the joining 3DS. The relay host can be a LAN machine
or public VPS running `tools/net_relay_server.go`; PC/Linux clients use the same
room with `--relay-join HOST XPLAY3D 17776`.

## Controls

- D-Pad Up/Down: select main-menu, map, settings, or lobby row
- A: confirm the selected row
- Campaign: opens the map picker; A loads the selected map
- Multiplayer: opens the local-wireless lobby menu
- Settings: toggles textures, cycles detail, or rescans maps
- B: return to the main menu after loading, error, map pick, or settings
- X: rescan maps from the Campaign map picker
- L/R: cycle 3DS geometry budget from the Campaign map picker
- Y: toggle experimental texture loading from the Campaign map picker
- Start: quit

In the local-wireless menus:

- D-Pad Up/Down: select action or lobby
- A: host, join, or start as host
- X: refresh lobby browser
- Y: toggle ready as client
- B: back or leave lobby

In loaded world view:

- Circle Pad: move player
- D-Pad Left/Right: turn
- D-Pad Up/Down: look up/down
- R: fire current weapon
- Y: reload
- X: swap carried weapon slot
- A: jump
- L: crouch
- B: return to menu

## Current Limitation

This target now uses the shared `HaloLoadedMap` path, renders the loaded BSP on 3DS, runs the shared game-world movement/weapon/projectile loop, initializes runtime vehicle state from parsed map placements, and draws a combat/weapon HUD overlay with a lightweight first-person weapon/hands stand-in. Vehicle placements are currently kept static on 3DS instead of running full mass-point vehicle physics every frame, because visible/drivable vehicle support is not present yet and the full physics path is too expensive for this target. BSP player collision is active; object/scenery collision is still disabled on 3DS until that path has its own budgeted broadphase. Local-wireless multiplayer currently synchronizes the lightweight player/combat session state and lobby flow, but it does not yet render remote player models on the 3DS world view. It still does not draw object/vehicle/player models, real first-person weapon models, projectile trails, sounds, or lightmap/detail texture layers. The next steps are visible object/vehicle/weapon rendering, item pickup support, remote player visualization for 3DS local wireless, and expanding the texture path beyond the base-map fallback once the fast color path is stable.

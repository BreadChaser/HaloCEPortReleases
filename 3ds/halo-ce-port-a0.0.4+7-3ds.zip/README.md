# Halo CE Port Test

This workspace is for evaluating practical ways to move Halo: Combat Evolved / Custom Edition behavior toward other platforms.

## What is here

- `targets/3ds-ringworld-prototype` - native 3DS `.map` cache probe target.
- `targets/linux-prototype` - retired compatibility wrapper that delegates to the native Linux runtime.
- `targets/linux-mesh-viewer` - the Linux SDL/OpenGL runtime executable for selecting, loading, rendering, playing, and testing owned CE `.map` files.
- `targets/windows-mesh-viewer` - MinGW-w64 cross-build wrapper for the same SDL/OpenGL runtime on Windows.
- `engine` - shared native runtime code organized by Halo-style subsystems: cache, tags, game, objects, physics, and networking.
- `runtime` - compatibility wrappers for older include paths; new shared code should live under `engine`.
- `third_party/invader` - open-source Halo 1 map/tag tooling.
- `third_party/chimera` - open-source Halo PC / Custom Edition runtime enhancement and hook code.
- `third_party/OpenSauce` - open-source Halo Custom Edition engine-extension research code.
- `third_party/halo-re-halo` - open-source Xbox Halo CE reimplementation/decompilation research.

## What is not here

This repo does not include Halo executables, maps, tags, sounds, textures, or other copyrighted game content. Put files from your own legal installation/copy under `resources/`; that folder is intentionally ignored and is meant to persist across launcher-installed game updates.

## Suggested local layout

```text
resources/
  maps/
    halo1/
      maps/
        bloodgulch.map
        bitmaps.map
        sounds.map
        loc.map
  halo_pc/
    haloce.exe
    maps/
      bloodgulch.map
      bitmaps.map
      sounds.map
      loc.map
  HaloCE/
    maps/
      custom_or_stock_ce.map
      bitmaps.map
  HaloReach/
    maps/
      reach_test_cache.map
  Test/
    maps/
      sandbox.map
  Chimera/
    maps/
      chimera_compat_test.map
  Custom/
    maps/
      my_custom_map.map
  halo_ce_tags/
    tags/
    data/
  xbox/
    cachebeta.xbe
    maps/
```

You can scan common Steam install paths with:

```bash
scripts/find_halo_inputs.sh
scripts/check_resources.sh
```

The runtime searches `resources/maps`, `resources/halo_pc/maps`, MCC-style
`resources/maps/halo1/maps`, and general engine buckets such as
`resources/HaloCE/maps`, `resources/HaloReach/maps`, `resources/Test/maps`,
`resources/Chimera/maps`, and `resources/Custom/maps`. It also recursively scans
executable-relative `resources` / `Resources` roots so custom missing buckets can
be dropped in without changing code. A launcher can point at a persistent asset
location with `HALO_CE_RESOURCE_DIR`, or at a specific map folder with
`HALO_CE_MAPS_DIR`.

## Near-term strategy

### No-rewrite route: binary compatibility

If the goal is a practical port without rewriting the engine, keep the PC executable as the runtime:

1. Use a legal Halo PC / Custom Edition install as input.
2. Run the Windows x86 executable through a compatibility stack on the target.
3. Patch/configure around the edges: input, resolution, file paths, networking, and launcher behavior.

For Android, this likely means testing with Wine plus Box86/Box64 packaging such as Winlator-style containers. For Linux handhelds or ARM Linux devices, this means Wine plus Box86/Box64 or FEX-style user-mode x86 translation. This is not a native port, but it is the closest path to "just port it" without rewriting the engine.

3DS is not a good fit for this route. It cannot reasonably run the Windows x86 PC binary, and the hardware budget is too small for a general Windows/x86 compatibility stack.

### Longer route: native runtime

If binary compatibility is not enough, the next path is much larger:

1. Use Halo Custom Edition / Halo PC as a known-good runtime.
2. Use Chimera/OpenSauce code to understand runtime patching, hooks, memory layout, renderer fixes, input, and scripting extensions.
3. Use Invader to inspect and extract/rebuild maps and tags from legal local game data.
4. Build a minimal standalone viewer that loads a simple map or extracted tag subset.
5. Port that viewer/runtime layer to Android before attempting constrained hardware like 3DS.

3DS should be treated as a later reduced-content target. It will likely require lower-resolution textures, simplified BSP rendering, reduced effects, and aggressive memory budgeting.

## Current host status

This machine has GCC/G++ installed. It is missing CMake, and likely missing several Invader/Chimera build dependencies such as Qt6, SDL2, libvorbis, libsamplerate, and libtiff development packages.

## Linux mesh viewer multiplayer

The current Linux runtime builds to one executable, `targets/linux-mesh-viewer/build/halo-ce-runtime`. From the repo root:

```bash
make linux
make windows SDL2_PREFIX=/path/to/SDL2-devel-2.x.x-mingw/SDL2-2.x.x/x86_64-w64-mingw32
make 3ds
make run
make test
```

## Versioning and release feed

Builds use the same `VERSION` / `BUILD` file pattern as `goland_voxel_vulkan`.
`make build` writes a versioned Linux runtime under `bin/linux-amd64/` and then
increments `BUILD` for the next build:

```bash
make build
./bin/linux-amd64/halo-ce-runtime-a0.0.1+0-linux-amd64 --version
```

Release publishing is split into two repositories:

- Private source repo: `git@github.com:BreadChaser/HaloCEPortTest.git`
- Release feed repo: `git@github.com:BreadChaser/HaloCEPortReleases.git`

`make publish-playtest` bumps the patch version, builds the Linux runtime, the
3DS homebrew target, and the Windows runtime when SDL2 cross-build settings are
configured, packages them into the release feed repo, updates `latest.json`, copies the current
SideLauncher self-update binaries from `LAUNCHER_SOURCE_DIR`, commits the
release, and pushes it when the remote exists. Use `--no-push` while testing:

```bash
./scripts/publish-playtest.sh --no-push
```

Use `--skip-windows` if the Windows SDL2 dev package is not installed, and
`--skip-3ds` if devkitARM/libctru/citro2d/citro3d are not installed. The
launcher keeps user-owned files in a persistent project-level `resources/`
folder and starts the runtime with `HALO_CE_RESOURCE_DIR` pointing there, so
playtest packages should not include stock Halo maps or assets. If
`release_resources/REDISTRIBUTABLE_RESOURCES.txt` exists, `publish-playtest`
bundles that directory into `resources/` inside each package for cleared test
maps/assets.

GitHub Releases can be published directly from this repo with:

```bash
./scripts/publish-github-release.sh
```

That script builds Linux, 3DS, and Windows when `SDL2_PREFIX` or explicit SDL2
cross-build flags are configured, packages those artifacts without game assets,
and creates or updates a GitHub prerelease through the `gh` CLI. Use
`--dry-run` to preview, `--skip-windows` if the Windows SDL2 dev package is not
installed, and `--skip-3ds` if the 3DS devkit is not installed on the build
machine.

Do not package stock Halo/MCC/CE maps or assets into public releases. If you
have custom maps/assets that are explicitly redistributable, put them in a
separate directory with a `REDISTRIBUTABLE_RESOURCES.txt` marker describing the
source/license, then publish with:

```bash
./scripts/publish-github-release.sh --resource-bundle /path/to/redistributable/resources
```

The Linux and 3DS native targets now include `engine/sources.mk` so shared
runtime source additions in `engine/cache`, `engine/game`, `engine/objects`,
`engine/physics`, and `engine/tags` are picked up by both builds. Linux also
builds `engine/net`; 3DS excludes that POSIX socket backend until it has a
platform adapter.

The runtime has a minimal UDP authoritative-host mode. Solo remains the default:

```bash
cd targets/linux-mesh-viewer
make
./build/halo-ce-runtime
```

Start a host:

```bash
./build/halo-ce-runtime --host 11775
```

Join from another instance or machine:

```bash
./build/halo-ce-runtime --connect 127.0.0.1 11775
```

The first network pass is intentionally simple: clients send input commands to the host each fixed simulation tick, the host owns player state, and snapshots are broadcast back. It does not yet include prediction, reconciliation, game rules, damage, or weapon state replication.

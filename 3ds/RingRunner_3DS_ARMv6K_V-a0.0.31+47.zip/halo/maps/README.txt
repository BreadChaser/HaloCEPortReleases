Place legally owned Halo CE .map files here on the SD card as /halo/maps/*.map.
This release does not include Halo game assets.

# Halo CE Port Resources

Put files from your own legal Halo CE / MCC installation here. This folder is intentionally not committed to the source repo and is shared across downloaded runtime versions.

Recommended layout:

```text
resources/
  bitmaps.map
  maps/
    halo1/
      maps/
        bloodgulch.map
        bitmaps.map
        sounds.map
        loc.map
        ui.map
      maps/custom_edition/
        bitmaps.map
        sounds.map
        loc.map
  halo_pc/
    maps/
      bloodgulch.map
      bitmaps.map
      sounds.map
      loc.map
```

Use one layout or the other. A launcher-level `resources/bitmaps.map` is also accepted for shared textures. The runtime also accepts direct map folders through `HALO_CE_MAPS_DIR` and a custom resource root through `HALO_CE_RESOURCE_DIR`.

Do not place owned Halo files inside versioned build folders such as `a0.0.2+1/`. SideLauncher replaces those folders when new builds are installed, while this `resources/` folder is kept.

Public releases include this README and an empty `resources/` skeleton. They do not include stock Halo/MCC/CE maps or assets. Release packages may include a separate redistributable resource bundle only when those files are cleared for redistribution.

The bundled Obelisk smoke-test map can load without stock map files, but common hand, weapon, item, HUD, and shared model textures still need `bitmaps.map` from your own legal Halo CE/MCC install. If those models render white or untextured, copy `bitmaps.map` into one of the layouts above, preferably the persistent launcher-level `resources/` folder rather than a versioned build folder.

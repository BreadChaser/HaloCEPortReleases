# Custom Gametypes

The runtime loads simple YAML-style gametype files from this folder, plus
`HALO_CE_GAMETYPES_DIR` when that environment variable is set.

In the runtime UI, open `Multiplayer > Host Public Game > Gametype` to edit the
selected gametype, starting weapons, score/time/respawn values, team options,
and friendly fire. `Save Copy` writes a new YAML file; `Overwrite` updates the
selected file or creates one for built-in defaults.

Supported keys:

```yaml
id: my_mode
name: My Mode
mode: 130
team_mode: true
teams: 2
score_limit: 50
time_limit_minutes: 15
respawn_seconds: 5
friendly_fire: false
starting_primary: weapons\pistol\pistol
starting_secondary: weapons\assault rifle\assault rifle
starting_frag_grenades: 2
starting_plasma_grenades: 0
```

Only `id`, `name`, `mode`, `team_mode`, and `teams` affect network setup today.
Starting weapon and grenade values are applied on player spawn. Score limits,
timers, respawn tuning, and friendly-fire rules are parsed but still reserved
for gameplay rule modules that will enforce custom win conditions and
mode-specific behavior.
